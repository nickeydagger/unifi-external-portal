<?php
	require_once('./config.php');
	
	sendAuthorization($_SESSION['unifiid'], '2', '700', '700', '50', $unifi);
		echo "success";
	
	//echo "success";

?>
