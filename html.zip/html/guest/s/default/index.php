<?php
	// Start a session to capure the id and url of the incomming connection
	/*$access_token ='640680139424484|4cf7be92fbeb170103c9126bc88dc57f';
	$app_secret		= '4cf7be92fbeb170103c9126bc88dc57f';
	$appsecret_proof= hash_hmac('sha256', $access_token, $app_secret);*/
	//echo $appsecret_proof;
	//session_start();
	require_once('./config.php');
	if (isset($_GET['id'])) {
	  $_SESSION['unifiid'] = $_GET['id'];
	} 
	else {
	  die("Direct Access is not allowed");
	}

	if (isset($_GET['url'])) {
	  $_SESSION['url'] = $_GET['url'];
	} else {
	  $_SESSION['url'] = 'https://www.google.com';
	}
	
	/*if(isset($_REQUEST['fbl']))  {
		sendAuthorization($_SESSION['unifiid'], '3330', $unifi);
			header('Location: https://www.google.com.mm');
		
    }*/
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN"
	"http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en" lang="en" dir="ltr" class="uk-height-1-1">
<head>
	<title>Hledan Centre - Free Wifi</title>
	<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<link rel="icon" href="hledan.png">
	<!-- UIKit Styles -->
	<link rel="stylesheet" href="css/bootstrap.min.css" />
	<link rel="stylesheet" href="css/uikit.active.css" />
	<link rel="stylesheet" href="css/custom.css" />	
	<script type="text/javascript" src="js/jquery-1.11.1.min.js"></script>
	
	<script type="text/javascript">
/*$(document).ready(function() {
      alert("document ready occurred!");
});	 */
  function showModal(){
	$('#loading').modal('show');
  }
 
   // This is called with the results from from FB.getLoginStatus().
  function statusChangeCallback(response) {
	$('#loading').modal('show');
    if (response.status === 'connected') {
      // Logged into your app and Facebook.
      testAPI();
    } else if (response.status === 'not_authorized') {
      // The person is logged into Facebook, but not your app.
	 // alert('notAuthorized');
	  $('#loading').modal('show');
      document.getElementById('status').innerHTML = 'Please log ' +
        'into this app.';
    } else {
		//alert('else');
      document.getElementById('status').innerHTML = 'Please log ' +
        'into Facebook.';
    }
  }
  function checkLoginState() {
	//alert('oki');
	 /* FB.getLoginStatus(function(response) {
      statusChangeCallback(response);
    });  */
  }

  // Here we run a very simple test of the Graph API after login is
  // successful.  See statusChangeCallback() for when this call is made.
  function testAPI() {
    console.log('Welcome!  Fetching your information.... ');
    FB.api('/me?fields=name,email,gender,age_range', function(response) {
      console.log('Successful login for: ' + response.name);
	  $name 	= response.name;
	  $profile	= response.id;
	  $email	= response.email;
	  $gender	= response.gender;	 
	  $age = JSON.stringify(response.age_range.min);
	  if($name != "undefined") {	  
      document.getElementById('status').innerHTML =
        'Thanks for logging in, ' + $name + '!';
	  }
	 window.location.href="https://google.com.mm";

		/* $.ajax({
          type: 'POST',
          url: 'savefb.php',
          data: {name:$name,email:$email,gender:$gender,age:$age,profile:$profile,is_ajax:'isajax'},
          success: function(response){
			document.getElementById('status').innerHTML =
        'Thanks for logging in, ' + $name + '!';
             //alert(response);
			 window.location.href="http://www.google.com.mm";
          }
        }); */
		
    });
  }
</script>
</head>

<body class="uk-height-1-1" <?php if(isset($_REQUEST['fbl'])) { ?> onload="javascript:showModal();" <?php } ?>>
<div id="bdy"></div>
	
	<div class="uk-vertical-align uk-text-center uk-height-1-1"><!-- Open Display Panel -->
		<div class="uk-vertical-align-middle" style="width: 320px;"> <!-- Set the column width here -->
			<div class="uk-container-center">

				<div class="uk-panel uk-panel-divider">&nbsp;</div> 
				
				</div>
				

				<!-- Logo Panel and Welcome Text -->
				<div class="uk-panel-box uk-panel-box-secondary">
					<span>&nbsp;</span>
					<div class="uk-panel-teaser">
						<img src="hledan.png" alt="Your Logo" />
					</div>
					<span class="uk-text-large" style="font-size:32px; color:#0080ff; letter-spacing:1px;">HLEDAN CENTRE <br /><span style="font-size:12px; color:#444;letter-spacing:3px;">PROPERTY MANAGEMENT <br></span></span>
					<br>
					<span class="uk-text-large">Welcome to our <br />Complementary WiFi Service!</span><br /><br />
					<span class="uk-text-large continue"><i>Click To Continue</i></span>
				</div> <!-- Close Logo Panel -->

				<div class="uk-panel uk-panel-divider">&nbsp</div> 

				<!-- UniFi Portal Forms Panel -->
				<div id="connect_panel" style="display:none;">
				<div class="uk-panel-box uk-panel-box-secondary">

					<!-- IF AUTH BY SIMPLE PASSWORD -->
						<form name="input" id="submit-form" name="submit-form" method="post" action="" class="uk-form">
							<input type="hidden" name="page_error" value="index.html" />
							<!-- Display either Please Enter Password or Error Message -->
							
							<div>
								<span class="uk-text-large">Connect with</span>
							</div>
							
							<!-- Password Input -->
							<div class="uk-panel-teaser" style="margin-top:10px;">
								<a href="#" onclick="fblogin_get();return false;"><img src="fb.png" alt="Facebook"></a>
							</div>
							<div class="or-divider"><div>OR</div></div>
							<div>
									<div class="uk-alert uk-alert-danger" data-uk-alert="" id="require_all" style="display:none;">
										<a href="#" class="uk-close require_all"></a>
										<p>For access, please enter All the fields below.</p>
									</div>
									<div class="uk-alert uk-alert-danger" data-uk-alert="" id="email_error" style="display:none;">
										<a href="#" class="uk-close email_error"></a>
										<p>Your email address is invalid!</p>
									</div>
									<div class="uk-alert uk-alert-danger" data-uk-alert="" id="age_error" style="display:none;">
										<a href="#" class="uk-close age_error"></a>
										<p>Age must contain only numbers!</p>
									</div>
							</div>
							<div>
								<fieldset>
									<input id="txtName" name="txtName" class="uk-width-1-1 uk-form-large" type="text" placeholder="Your Name" value="" autocomplete="off">
								</fieldset>
								<fieldset>
									<input id="txtEmail" name="txtEmail" class="uk-width-1-1 uk-form-large" type="text" placeholder="Your Email" value="" autocomplete="off">
								</fieldset>
								<fieldset>
									<select id="txtGender" name="txtGender" class="uk-width-1-1 uk-form-large">
										<option value="">Gender</option>
										<option value="male">Male</option>
										<option value="female">Female</option>
									</select>
								</fieldset>
								<fieldset>
									<input id="txtAge" name="txtAge" class="uk-width-1-1 uk-form-large" type="text" placeholder="Your Age" value="" autocomplete="off" maxlength="2">
								</fieldset>
							</div>
							<!-- Submit Button -->							
							<div>
								<input name="connect" type="submit" value="Connect" id="connect" class="uk-button-large uk-button-primary uk-width-1-1" />
							</div>
						</form>
					
				</div> <!-- Close UniFi Portal Forms Panel -->

				<div class="uk-panel uk-panel-divider">&nbsp</div>

				<!-- Terms of Use Panel -->
				<div class="uk-panel-box uk-panel-box-secondary">
					<h3 class="uk-panel-title"><i class="uk-icon-legal"></i> Terms of Use</h3>
					<p>By proceeding, you confirm you have read, understand and accept the <a href="#termsmodal" data-uk-modal >Terms of Use</a></p>
				</div> <!-- Close Terms of Use Panel -->
				</div><!-- connect panel -->
				<div class="uk-panel uk-panel-divider">&nbsp;</div>
				<br />
				<br />
				<br />
				<br />
				<br />
				
				<div class="uk-panel">
					<span class="uk-text-small">Wireless Network by<a href="http://www.nexus.com.mm" target="_blank"> nexus.com.mm</a></span>
				</div> <!-- Close Plug Panel -->
       
			</div>
		</div>	
	</div> <!-- Main Display Panel is now Closed -->

	<!-- This is the Modal Popup box for Terms of Use -->
	<div class="uk-modal" id="termsmodal">
		<div class="uk-modal-dialog">
			<a class="uk-modal-close uk-close"></a>
			<h3><i class="uk-icon-legal"></i> Terms of Use</h3>
			<p>By accessing the wireless network, you acknowledge that you're of legal age, you have read and understood and agree to be bound by this agreement</p>
			<ul>
				<li>The wireless network service is provided by the property owners and is completely at their discretion. Your access to the network may be blocked, suspended, or terminated at any time for any reason.</li>
				<li>You agree not to use the wireless network for any purpose that is unlawful and take full responsibility of your acts.</li>
				<li>The wireless network is provided &quot;as is&quot; without warranties of any kind, either expressed or implied. </li>
			</ul>
		</div>
	</div>
<!-- Loading modal -->
      <div class="modal fade" id="loading" tabindex="-1" role="dialog" aria-hidden="true">
        <div class="modal-dialog modal-sm">
          <div class="modal-content">
            <div class="modal-header">
              <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
              <h4 class="modal-title">Status...</h4>
            </div>
            <div class="modal-body">
              <p class="text-center" id="status">Please wait while computer is being authorized. <img src='./img/ajax-loader.gif' /></p>
            </div>
          </div>
        </div>
      </div>	
	
	<script type="text/javascript" src="js/bootstrap.min.js"></script>
	<script type="text/javascript" src="js/uikit.min.js"></script>

</body>
</html>
<script type="text/javascript"> 
$( ".continue" ).on( "click", function() {
	$(".continue").slideUp();
	$("#connect_panel").slideDown();
});

$( "#submit-form" ).submit(function( event ) {
  document.getElementById('status').innerHTML = "Please wait while computer is being authorized. <img src='./img/ajax-loader.gif' />";
  $('#loading').modal('show');
  var name		= $("#txtName").val();
  var email		= $("#txtEmail").val();
  var gender	= $("#txtGender").val();
  var age		= $("#txtAge").val();
  if(name	== "" || email	== "" || gender == "" ||age == ""){
	$("#require_all").fadeIn();
	return false;
  } else {
	  if(!validateEmail(email)){
		$("#require_all").fadeOut();
		$("#email_error").fadeIn();
		$("#txtEmail").focus();
		return false;
	} 
	else if(!( $.isNumeric( age ) ) ){
		$("#require_all").fadeOut();
		$("#email_error").fadeOut();
		$("#age_error").fadeIn();
		$("#txtAge").focus();
		return false;
	}else{
		$("#require_all").fadeOut();
		$("#email_error").fadeOut();
		$("#age_error").fadeOut();	
		var url = '';
		$.ajax({
		  type: 'POST',
		  url: 'authorize.php',
		  data: $('#submit-form').serialize(),
		  success: function(msg){
			 $("#status").html(msg);
			$('#loading').modal('show');
			window.location.href="https://www.google.com.mm";
			return false;			 
		  },
		  error: function(data, status, e)
			{
				alert(data.error);
				return false;
			}
		});
		// Show a loading modal
		
		} 
		//alert('oki');		
		return false;
		e.preventDefault();
}	
	
});
$( ".require_all" ).on( "click", function() {
	$("#require_all").fadeOut();
});
$( ".email_error" ).on( "click", function() {
	$("#email_error").fadeOut();
});

$( ".age_error" ).on( "click", function() {
	$("#age_error").fadeOut();
});

function validateEmail($email) {
  var emailReg = /^([\w-\.]+@([\w-]+\.)+[\w-]{2,4})?$/;
  return emailReg.test( $email );
}
function fblogin() {
	
	//$('#loading').modal('show');
	 if($("#bdy").html() ==  ""){
		$('#status').html('<a href="#" onclick="fblogin_process();return false;">Click Here</a> to sign in with facebook and Get Our Free Wifi Access.');	
	} 
	 $.ajax({
	  type: 'POST',
	  url: 'getauthorize.php',
	  data: {isajax:'yes'},
	  success: function(msg){
		$("#bdy").html(msg);
		//window.location.reload();
		 
	  }
	}); 	
	
	$('#loading').modal('show');
	alert($("#bdy").html());
	
	FB.login(function(response) {			
	  statusChangeCallback(response);
	}, {scope:'public_profile,email'});
  } 
  
  function fblogin_process() {
    // $('#status').html('Please wait while computer is being authorized... <img src="./img/ajax-loader.gif" />');	
	 $.ajax({
	  type: 'POST',
	  url: 'getauthorize.php',
	  data: {isajax:'yes'},
	  success: function(msg){
		$("#bdy").html(msg);
		 
	  },
	   error: function(data, status, e)
			{
				alert(data.error);
				return false;
			}
	}); 	
	
	//$('#loading').modal('show');
	
	FB.login(function(response) {			
	  statusChangeCallback(response);
	}, {scope:'public_profile,email'});
  }


function fblogin_get() {
	 document.getElementById('status').innerHTML = "Please wait while computer is being authorized. <img src='./img/ajax-loader.gif' />";
  $('#loading').modal('show');

	 $.ajax({
	  type: 'POST',
	  url: 'getauthorize.php',
	  data: {isajax:'yes'},
	  success: function(msg){
		if(msg == "success") {
			//window.location="http://portal.nexus.com.mm/fb.php";
			window.location="fb.php";
	    } 
	  }
	}); 
  } 
    
  

</script>
