<?php
require_once('./config.php');
date_default_timezone_set('Asia/Rangoon');
$created = date("Y-m-d H:i:s");

if ($_POST) { // Check to see if the form has been posted to
  // Set and sanitze the posted variables
  $name		= preg_replace("/[^a-zA-Z0-9.]/", "", $_POST['txtName']);
  $email 	= $_POST['txtEmail'];
  $gender 	= $_POST['txtGender'];
  $age	 	= $_POST['txtAge'];
  $guest = array("name"=>$name, "email"=>$email, "gender"=>$gender, "age"=>$age, "created"=>$created);
   sendAuthorization($_SESSION['unifiid'], '30', '500', '500', '50', $unifi);
    // See if the user exists in SQL
    //if (authorizeSQL($user, $pass)) {
	if (addUser($guest)) {    
     // echo "<script type='text/javascript'>$(location).attr('href','".$_SESSION['url']."');</script>";
      echo ("Successfuly Connected");
    } else {
      echo "Couldn't authorize user please try again.";
    }
}
?>
