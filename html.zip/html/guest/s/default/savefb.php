<?php
	/* marge code */
	require_once('./config.php');
	/*$hostname='localhost';
	$username='root';
	$password='UserP@ssw0rd';
	$dbname		= "unifi";
	
	$supportEmail	= "eiphyo@axiom.com.mm";*/
	

// Date settings
date_default_timezone_set('Asia/Rangoon');
$created = date("Y-m-d H:i:s");

/**********************************************************************/
//                         End configuration                          // 
/**********************************************************************/
/**********************************************************************/
//                         End configuration                          // 
/**********************************************************************/
if(isset($_POST['is_ajax']) && $_POST['is_ajax'] == "isajax") {
		$name	= $_POST['name'];
		$email	= $_POST['email'];
		$age	= $_POST['age'];
		$gender	= $_POST['gender'];
		$profile= $_POST['profile'];
		
		sendAuthorization($_SESSION['unifiid'], '30', '500', '500', '50', $unifi);
		
		try {
		  //open the database
		  //$db = new PDO($dbType.':'.$dbName);
		  $db = new PDO("mysql:host=$hostname;dbname=$dbname",$username,$password);

		  $db->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
		} catch(PDOException $e) {
		  error_log('Database exception: '.$e->getMessage(), 1, $supportEmail);
		  echo('Exception: '.$e->getMessage());
		}
		 try {
			// See if user is in the database
			$chk = $db->prepare('SELECT email FROM fb_users WHERE email = :email');
			$chk->bindParam(':email', $email, PDO::PARAM_STR); 
			$chk->execute();
			//$result = $chk->fetch();
			$count = $chk->rowCount();
			if($count > 0){
				$db = NULL;
				echo "email exist";
			} else {
				try {
					// Insert a new user database			
					$sql = "INSERT INTO fb_users (name, email, gender, age, profile_id, created) VALUES (:name, :email, :gender, :age, :profile_id, :created)";
					$sth = $db->prepare($sql);
					$sth->bindParam(':name', $name, PDO::PARAM_STR);
					$sth->bindParam(':email', $email, PDO::PARAM_STR);
					$sth->bindParam(':gender', $gender, PDO::PARAM_STR);
					$sth->bindParam(':age', $age, PDO::PARAM_STR);
					$sth->bindParam(':profile_id', $profile, PDO::PARAM_STR);
					$sth->bindParam(':created', $created, PDO::PARAM_STR);
					$sth->execute();
					echo "success";
				  } catch(PDOException $e) {
					error_log('addUser exception: '.name.' Message: '.$e->getMessage(), 0);
					echo "error 1";
				  }
				
			}
			//$db = NULL; // Close the connection
			//echo "email exist";
		  } catch(PDOException $e) {
				error_log('addUser exception: '.name.' Message: '.$e->getMessage(), 0);
				echo $count;
				
		  }
		
	}
?>