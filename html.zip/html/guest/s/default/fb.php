<?php

// Start a session to capure the id and url of the incomming connection
	/* $access_token ='640680139424484|4cf7be92fbeb170103c9126bc88dc57f';
	$app_secret		= '4cf7be92fbeb170103c9126bc88dc57f';
	$appsecret_proof= hash_hmac('sha256', $access_token, $app_secret); */
	//echo $appsecret_proof;
//session_start();
require_once('./config.php');
/* if (isset($_GET['id'])) {
  $_SESSION['unifiid'] = $_GET['id'];
} else {
  die("Direct Access is not allowed");
} */

/* if (isset($_GET['url'])) {
  $_SESSION['url'] = $_GET['url'];
} else {
  $_SESSION['url'] = 'http://www.google.com';
} */
if(isset($_SERVER['HTTP_REFERER'])){
	$preURL = $_SERVER['HTTP_REFERER'];
} else {
	$preURL = "";
}

//sendAuthorization($_SESSION['unifiid'], '2', $unifi);
  //echo "<script type='text/javascript'>$(location).attr('href','".$_SESSION['url']."');</script>";
 // echo "Successfuly Connected";
// Setup the session variables and display errors if not set
//echo $_SESSION['id'];

// Display the login form
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en" lang="en" dir="ltr" class="uk-height-1-1">
<head>
	<meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="Wireless Portal Page">
	<title>Hledan Centre - Free Wifi</title>
    <link rel="stylesheet" href="css/bootstrap.min.css" />
	<link rel="stylesheet" href="css/uikit.active.css" />
	<link rel="stylesheet" href="css/custom.css" />	
	<link rel="icon" href="hledan.png">
	<script type="text/javascript" src="js/jquery-1.11.1.min.js"></script>
 
  <script type="text/javascript">
  // This is called with the results from from FB.getLoginStatus().
  function statusChangeCallback(response) {
    if (response.status === 'connected') {
      // Logged into your app and Facebook.
      testAPI();
    } else if (response.status === 'not_authorized') {
      // The person is logged into Facebook, but not your app.
	 // alert('notAuthorized');
	  $('#loading').modal('show');
      document.getElementById('status').innerHTML = 'Please log ' +
        'in to this app.';
    } else {
		//alert('else');
	$('#loading').modal('show');
      document.getElementById('status').innerHTML = 'Please log ' +
        'in to Facebook.';
    }
  }
  function checkLoginState() {
	//alert('oki');
	 /* FB.getLoginStatus(function(response) {
      statusChangeCallback(response);
    });  */
  }

  window.fbAsyncInit = function() {
  FB.init({
    appId      : '640680139424484',
    cookie     : true,  // enable cookies to allow the server to access 
                        // the session
    xfbml      : true,  // parse social plugins on this page
    version    : 'v2.2' // use version 2.2
  });
  FB.getLoginStatus(function(response) {
    //statusChangeCallback(response);
  }); 

  };

  // Load the SDK asynchronously
  (function(d, s, id) {
    var js, fjs = d.getElementsByTagName(s)[0];
    if (d.getElementById(id)) return;
    js = d.createElement(s); js.id = id;
    js.src = "//connect.facebook.net/en_US/sdk.js";
    fjs.parentNode.insertBefore(js, fjs);
  }(document, 'script', 'facebook-jssdk'));
  FB.login(function(response) {			
		 // statusChangeCallback(response);
		}, {scope:'public_profile,email'});

  // Here we run a very simple test of the Graph API after login is
  // successful.  See statusChangeCallback() for when this call is made.
  function testAPI() {
    console.log('Welcome!  Fetching your information.... ');
    FB.api('/me?fields=name,email,gender,age_range', function(response) {
      console.log('Successful login for: ' + response.name);
	  $name 	= response.name;
	  $profile	= response.id;
	  $email	= response.email;
	  $gender	= response.gender;	 
	  $age = JSON.stringify(response.age_range.min);
	  if($name != "undefined") {	  
      document.getElementById('status').innerHTML =
        'Thanks for logging in, ' + $name + '!';
	  }
	  $('#loading').modal('show');
		 $.ajax({
          type: 'POST',
          url: 'savefb.php',
          data: {name:$name,email:$email,gender:$gender,age:$age,profile:$profile,is_ajax:'isajax'},
          success: function(response){
			document.getElementById('status').innerHTML =
        'Thanks for logging in, ' + $name + '!';
             //alert();
			 
			window.location.href="https://www.google.com.mm";
			e.preventDefault();
          },
	      error: function(data){
				    alert(data.error);
				    }
        });
		
    });
  }
</script>
</head>
 <body class="uk-height-1-1">
 <div class="mybody">
    <div class="uk-vertical-align uk-text-center uk-height-1-1"><!-- Open Display Panel -->
		<div class="uk-vertical-align-middle" style="width: 320px;"> <!-- Set the column width here -->
			<div class="uk-container-center">

				<div class="uk-panel uk-panel-divider">&nbsp;</div> 

				<!-- Logo Panel and Welcome Text -->
				<div class="uk-panel-box uk-panel-box-secondary">
					<span>&nbsp;</span>
					<div class="uk-panel-teaser">
						<img src="hledan.png" alt="Your Logo" />
					</div>
					<span class="uk-text-large" style="font-size:32px; color:#0080ff; letter-spacing:1px;">HLEDAN CENTRE <br /><span style="font-size:12px; color:#444;letter-spacing:3px;">PROPERTY MANAGEMENT <br></span></span>
					<br>
					<span class="uk-text-large">Welcome to our <br />Complementary WiFi Service!</span><br /><br />
					<span class="uk-text-large continue"><i><a href="#" onclick="fblogin();return false;">Click Here To Connect With Facebook</a></i></span>
				</div> <!-- Close Logo Panel -->

				<div class="uk-panel uk-panel-divider">&nbsp</div> 

				<!-- UniFi Portal Forms Panel -->
				

				<!-- Terms of Use Panel -->
				<div class="uk-panel">
					<span class="uk-text-small">Wireless Network by<a href="http://www.nexus.com.mm" target="_blank"> nexus.com.mm</a></span>
				</div> <!-- Close Plug Panel -->
       
			</div>
		</div>	
	</div> <!-- Main Display Panel is now Closed -->

	<!-- This is the Modal Popup box for Terms of Use -->
	<div class="uk-modal" id="termsmodal">
		<div class="uk-modal-dialog">
			<a class="uk-modal-close uk-close"></a>
			<h3><i class="uk-icon-legal"></i> Terms of Use</h3>
			<p>By accessing the wireless network, you acknowledge that you're of legal age, you have read and understood and agree to be bound by this agreement</p>
			<ul>
				<li>The wireless network service is provided by the property owners and is completely at their discretion. Your access to the network may be blocked, suspended, or terminated at any time for any reason.</li>
				<li>You agree not to use the wireless network for any purpose that is unlawful and take full responsibility of your acts.</li>
				<li>The wireless network is provided &quot;as is&quot; without warranties of any kind, either expressed or implied. </li>
			</ul>
		</div>
	</div>
<!-- Loading modal -->
      <div class="modal fade" id="loading" tabindex="-1" role="dialog" aria-hidden="true">
        <div class="modal-dialog modal-sm">
          <div class="modal-content">
            <div class="modal-header">
              <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
              <h4 class="modal-title">Status...</h4>
            </div>
            <div class="modal-body">
              <p class="text-center" id="status">Please wait while computer is being authorized. <img src='./img/ajax-loader.gif' /></p>
            </div>
          </div>
        </div>
      </div>	
	
	<script type="text/javascript" src="js/bootstrap.min.js"></script>
	<script type="text/javascript" src="js/uikit.min.js"></script>
    <!-- jQuery form validation -->

    <!-- Page specific JavaScript -->
    <script type="text/javascript">
	function fblogin() {
		//$('#loading').modal('show');
		FB.login(function(response) {			
		  statusChangeCallback(response);
		}, {scope:'public_profile,email'});
	  }
      // Login form processing
      $('#login').submit(function(e){
        e.preventDefault();
        var url = '<?php echo $_SESSION['url']; ?>';
        if (!$('#terms').is(':checked')) {
          alert("You must accept the terms of service");
          return false; // stop the form submission
        }
        $.ajax({
          type: 'POST',
          url: 'authorize.php',
          data: $('#login').serialize(),
          success: function(msg){
             $("#status").html(msg);
          }
        });
        // Show a loading modal
        $('#loading').modal('show');
      });

     /*  $('#loading').on('hidden.bs.modal', function () {
        $("#status").html("Please wait your device is being authorized. <img src='./img/ajax-loader.gif'/>");
      }); */
    </script>
    </div>
  </body>
</html>
